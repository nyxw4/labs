var http = require('http');
var express = require('express');
var path = require('path');

var app = express();

app.use(express.static('../'));

app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname, '..', 'LAB2', 'project.html'));
});

app.get('/home.html', function(req, res) {
    res.sendFile(path.join(__dirname, '..', 'LAB2', 'index.html'));
});

app.get('/project.html', function(req, res) {
    res.sendFile(path.join(__dirname, '..', 'LAB2', 'project.html'));
});

var server = http.createServer(app);

server.listen(80, '0.0.0.0');

console.log("servidor rodando...");